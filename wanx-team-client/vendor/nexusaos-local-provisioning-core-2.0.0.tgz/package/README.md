# @nexusaos/local-provisioning-core

Transport-neutral strict codec and cryptographic state for `NEXUSAOS_LOCAL_AEAD_V2`. Crypto and certificate operations are injected through `ProvisioningCryptoProvider`; no weak fallback exists.

BLE discovery can return the same 12-field Device Info with `pairing_mode_remaining_seconds: 0`. A registered device may report `cloud_enrollment_status: "ready"`; an unregistered device reports `"not_enrolled"`, which is valid only with a zero pairing window. Both zero-window forms are public, read-only previews. They do not authorize Wi-Fi changes, Device Proof or account claim, and the coordinator rejects a zero window before starting secure pairing. A positive pairing window still requires the existing verified factory handoff and enrolled device identity; cryptographic vectors and ticket formats are unchanged.
