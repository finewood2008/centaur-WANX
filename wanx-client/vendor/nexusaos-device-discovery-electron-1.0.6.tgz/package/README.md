# @nexusaos/device-discovery-electron

Electron Main system-chooser discovery v1. It contains no provisioning commands, Wi-Fi payloads, GATT codec, or legacy plaintext implementation.

Install `installElectronBluetoothPicker` from `./main` before the trusted Setup
Renderer calls `navigator.bluetooth.requestDevice()` from a user gesture.
Install the host only for that trusted document, which must filter by the fixed
provisioning service UUID using `createElectronBluetoothSelectionEndpoint()`.
Do not use a name-prefix filter: macOS/Chromium may expose a cached system name
such as `user`, or an empty name, even when the current BLE advertisement has a
`CentaurOS-Setup-` name. The host accepts those names as untrusted display hints,
rejects names longer than 64 characters and names containing control characters.
It does not invent names or treat a candidate as proof of box identity. GATT identity reading and
certificate-backed challenge verification must follow selection before any
network or account-binding operation.

An optional Main-only `advertisementNames.subscribe(onName)` provider can supply
fresh BLE advertisement names as `{ deviceId, advertisedName, displayIdentity? }`, or `null` for
`advertisedName` to withdraw metadata and restore that device's cached name. It
must strictly associate the native peripheral with the exact internal Chromium chooser device
ID; never correlate by cached name, name suffix, list order, or Renderer candidate
ID. Subscription starts once per user-initiated chooser session and must scan
fresh metadata for that session. Only names of 1–64 characters without control
characters are accepted. Matching advertisement names override cached system
names for display, including when metadata arrives before the chooser entry;
unmatched candidates keep their system names.
The provider may additionally supply `displayIdentity: { deviceId, displayName? }`
read from the same native peripheral's public, read-only GATT identity. The outer
`deviceId` remains the exact internal Chromium chooser ID; the nested `deviceId`
is the complete box ID (1–36 ASCII letters, digits, dot, underscore or hyphen).
Optional names must contain 1–64 characters without control characters; leading
and trailing whitespace is trimmed, and whitespace-only names fall back to the
box ID. Invalid identity values do not replace existing identity metadata and do
not discard a valid advertisement name. An omitted `displayIdentity` preserves
that session's existing hint; explicit `null` withdraws it. Withdrawing the
advertisement name also clears the identity hint.

Candidate-list messages alone include `nameSource: "advertisement"` for exact
advertisement matches and `displayIdentity` for exact provider identity matches.
Internal candidates and `settled.selected` do not gain either field, so the GATT
selection contract stays unchanged. Public GATT identity hints are not yet
authenticated: use the name first, or the complete box ID when no name is present,
only for display. They must never select a different chooser entry, authorize
connection, or authorize network configuration/account binding.
Selection still uses the original Chromium ID and opaque candidate handles.
Provider failures fall back to existing
discovery. Selection, cancellation, timeout, and disposal unsubscribe; stale
callbacks cannot update later sessions. Neither cached nor advertisement names
prove identity. Even when a public GATT hint includes the full box ID, read that
ID again through the selected GATT transport and verify the certificate-backed
challenge before configuration.

Installation is passive: the resulting Chromium `select-bluetooth-device` event
starts one fresh session (eight seconds by default). Hosts may configure
`scanTimeoutMs` up to 12000 ms to allow a late advertisement's public, read-only
Device Info probe to finish. Values above 12000 ms are clamped; existing callers
that omit this setting retain the eight-second timeout. Select, cancel, or timeout releases that
session while leaving the host ready for the next user click. The host publishes
opaque selection handles and optional public display hints on
`DISCOVERY_PICKER_CHANNELS.candidates`;
the preload forwards an explicit `select` or `cancel` IPC from the same
`webContents.mainFrame` and exact internal document URL. The returned synchronous,
idempotent cleanup function removes the discovery IPC handlers, cancels the Chromium chooser,
and disposes the scan.

Selection of the Chromium chooser entry only resolves the Renderer Web Bluetooth
promise. The Renderer must then use
`createElectronBluetoothSelectionEndpoint()` from
`@nexusaos/local-provisioning-electron-ble` to issue the one-shot selection lease
that binds the in-memory `BluetoothDevice` to the GATT transport factory.

After a scan ends, the trusted Renderer may keep its results selectable. Main
retains only the latest scan's opaque candidate-to-original-provider mapping,
with at most 128 entries and a 120-second lifetime. It does not retain the old
Chromium callback or a usable GATT lease. On a new user click, preload sends
`DISCOVERY_PICKER_CHANNELS.reselect` with `{ sessionId, candidateId }` from the
completed scan and the Renderer synchronously starts a fresh service-filtered
`requestDevice()` in the same click gesture. Main selects only the exact original
provider ID when it appears in that new chooser, publishing only the target's
fresh candidate. It never matches names, public box IDs, suffixes or list order.
The fresh chooser may arrive before the reselection IPC; that ordering is also
supported. The pending intent expires after 15 seconds if no chooser arrives.
A fresh chooser uses the normal bounded scan timeout. Missing targets fail
without selecting another device; the original snapshot remains available for
retry until its 120-second expiry. Successful selection clears it. Ordinary new
scans replace the snapshot when they end.

On closing Setup, account changes, logout or document navigation, preload must
send `DISCOVERY_PICKER_CHANNELS.forget` with `{ sessionId }` for retained results.
It revokes that snapshot and any pending or active reselection using it; active
scans should also be cancelled. Disposal clears all retained/pending state and
removes all four IPC handlers. Reselection preserves the provisioning contract:
Main publishes a fresh opaque selected candidate with no display-only identity
fields, and the Renderer selection endpoint issues a new one-shot lease from
the newly resolved BluetoothDevice. Old leases are never replayed.
