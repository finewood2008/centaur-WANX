# centaurai-wanx — 完整 WANX 功能接口 SDK

`centaurai-wanx` 是面向知君及其他 WANX 应用的通用客户端 SDK。它直接调用 WANX（原 Octop）的账号、Agent、记忆、聊天、知识库、工具、插件、工作区与管理模块，并复用最新 Codeup Go SDK/Core 连接盒子。应用无需自建账号协议、连接协议或记忆数据库。

当前版本 **`0.1.0-alpha.3`** 已有可执行客户端和本地安装包，并新增15项产品管理与应用档案接口（客户端总计43个模块、472项HTTP操作）。它是完整 WANX 功能接口 SDK，覆盖固定平台快照中的 **42 个模块、457 项公开 HTTP 操作、31 项原生记忆操作及 7 类 WebSocket**。这些是客户端覆盖范围；模块运行仍取决于服务端版本、用户权限、应用授权、Agent 状态与相应服务配置。

本轮按用户要求不进行盒子联调。接口绑定、本地 HTTP/WS、Go 原生进程和 Electron IPC 使用本机合成服务测试；不能据此宣称生产服务端或真实跨网络连接已验收。

## 安装

需要 Node.js 22+。使用本地交付包安装：

```sh
npm install /path/to/centaurai-wanx-0.1.0-alpha.3.tgz
```

发布包包含编译后的 JavaScript、类型、native host 与 SHA256 清单；应用运行时无需安装 Go。源码构建需要 Go 1.24+、Python 3、Node.js、npm 和 make。此 Codeup 分支提供 SDK 源码与本地交付包，未发布 npm/Go tag，也未进行生产部署。

## 能力与边界

| 能力 | SDK 实现 | 当前平台合同 |
| --- | --- | --- |
| WANX 全部公开模块 HTTP | 457 项实际调用绑定，完整原生参数和状态码 | 固定 API 快照；服务端权限继续生效 |
| 原生记忆 | 30 项 Agent 记忆门面及 1 项主机来源选择 | 直接使用原生记忆模块；迁移需单独授权 |
| 平台账号 | 密码/SMS 登录、自动刷新协调、登出、安全存储 | 使用现有 Consumer 账号 |
| 盒子连接 | 设备目录、签票、P2P、设备身份校验和关闭 | 最新批准的 `omnia-desktop`、Direct-only |
| WANX 原生身份 | challenge/grant/exchange、JIT 用户、续租、显式关联、owner 初始化 | 复用 Go `omniaauth` 客户端；匹配服务端未联调 |
| SSE / 下载 | 字节流、跨块 UTF-8 SSE、取消、显式关闭 | P2P 使用 app v2 响应流；下载可超过 unary 限额 |
| WebSocket | 聊天、通知、终端、浏览器、桌面、手机及 ADB shell | 原生鉴权由可信宿主注入；部分模块条件启用 |
| 上传 | JSON、二进制、multipart/FormData；文件名与字节保留 | P2P 编码后请求最大 2 MiB；上传流未批准 |
| Electron | main、sandbox preload、renderer 门面、窗口/导航隔离 | 主进程运行 native host；凭据不进入页面 |
| 其他登记应用 / Relay | 公共 API 层可复用；自定义受审 transport 可注入 | 内置 P2P 不借用其他应用身份，不宣称已支持新签票/SSO 合同或 Relay |

3 项内部 MCP 服务接口不属于外部应用 API，因此不开放到公共模块。Android/iOS/H5 未纳入本版运行环境承诺。Windows/Linux 的编译产物和运行验收分别记录，不能把交叉编译等同于目标机器运行通过。

对外名称统一为 `centaurai-wanx`。`omnia-desktop`、`omnia.use`、`nexusaos.p2p-app.v2` 及既有 `octop` 服务端标识保留原合同；改这些字段需要平台共同升级，不能仅在 SDK 替换字符串。

## 连接盒子

在 Electron main 的 `app.whenReady()` 后创建宿主。安全存储使用 Electron `safeStorage`；部署配置和应用策略由安装包的可信主进程提供。

```ts
import { app, safeStorage } from "electron";
import { createCentaurAIWanxHost, createElectronSecureStore } from "centaurai-wanx";

await app.whenReady();
const host = await createCentaurAIWanxHost({
  consumerBaseURL: deployment.consumerBaseURL,
  trustedGatewayHosts: deployment.trustedGatewayHosts,
  trustedICEHosts: deployment.trustedICEHosts,
  secureStore: createElectronSecureStore({
    safeStorage, directory: app.getPath("userData"),
  }),
  policy: approvedApplicationPolicy,
});

await host.auth.loginPassword({ phone, password });
const devices = await host.devices.list();
const sdk = await host.connection.connect({ deviceId: selectedDeviceId });
const memory = sdk.agents.use(authorizedAgentId).memory;
const result = await memory.listAtoms({ body: { limit: 20 } });
console.log(result.status, result.body);
// 应用退出时关闭账号宿主与所有连接。
await host.dispose();
```

设备 ID 必须来自已登录的设备目录。当前内置 P2P 的 `policy.applicationId` 必须与已批准的 `omnia-desktop` 合同一致；改成任意新应用时会返回 `APPLICATION_CONTRACT_NOT_SUPPORTED`。产品名称不等于网络 applicationId。

`policy.operations` 指定完整 operationId；`policy.agents` 限定 Agent；`policy.sockets` 限定 WS 类型。它是本机能力边界，不会授予服务端管理员权限或替代服务端应用授权。生产策略须来自公司批准的部署配置，页面不能修改主进程策略。

现有原生用户关联通过 main 调用 `connect({ deviceId, linkExisting: { username, password } })`；首次 owner 初始化使用 `host.initializeOwner(wizardToken)`。这两个流程必须使用用户明确提供的证明，不自动映射既有管理员账号。

## 调用模块、记忆与流

每个原生模块都在 `sdk.modules` 下提供稳定方法别名；原生 operationId、路径、参数、上传形式见[完整 API 目录](docs/api-reference.md)。应用 Agent 绑定客户端省略路径中的 `agent_id`，并拒绝覆盖该身份。

```ts
const agent = sdk.agents.use(authorizedAgentId);
await agent.memory.getAtom({ path: { atom_id: nativeAtomId } });
await agent.memory.listCandidates({ body: { limit: 20 } });
// 写入保持原生结构与原生权限，不另建知君记忆系统。
await agent.memory.createAtom({ body: nativeCreateAtomBody });

const form = new FormData();
form.append("file", new Blob([packBytes]), "memory.hmpkg");
await agent.memory.doctorPortable({ body: form });

// 下载或大响应使用 stream；普通调用的响应上限为 16 MiB。
const response = await agent.memory.packPortable.stream({ body: portableOptions });
try { for await (const bytes of response.chunks) await sink.write(bytes); }
finally { await response.close(); }

const socket = await sdk.openSocket({ endpoint: "chat", agentId: authorizedAgentId });
await socket.send({ kind: "text", text: JSON.stringify(nativeUserTurnFrame) });
for await (const frame of socket.frames) consumeNativeChatFrame(frame);
await socket.close();
```

所有模块方法提供 `.stream(request, options)` 和 `.events(request, options)`。`.events` 用于原生 SSE 路由；它保留 `event/data/id/retry`，不自动重连或重放写入。关闭流与取消远端聊天任务不同：任务取消仍须调用原生取消接口或原生 WS cancel 帧。

SDK 保留 HTTP `status/body`，普通 4xx/5xx 不改写成成功，不自动重放 POST。网络失败返回稳定 `WanxError.code`。原生响应未在 OpenAPI 明确描述时，类型保持 `unknown`；不编造服务端字段。

完整 `sdk.native.invoke/stream` 只供可信宿主。页面不能传 Authorization、token、cookie 或 `as_user`，也不能覆盖已绑定 Agent。原生 token 只在 main/native 内注入原生请求和 WS 握手。

## Electron 与其他接入

[Electron 完整接入](docs/electron.md)包含 main、sandbox preload、renderer、销毁及打包路径。页面只接收固定 IPC 门面，使用同一模块 API；不导入 root/main 入口，不持有 native client。

已有 WANX HTTP/HTTPS 部署可在可信 Node 宿主使用 `createHTTPTransport({ baseURL, token })` 后创建 `createCentaurAIWanxClient({ transport, policy })`。`token` 是宿主回调。HTTPS 可指向受信部署；明文 HTTP 仅允许本机 loopback。`createNativeHTTPTransport` 用于经过 Go 进程的本地集成验证，并不代表 P2P 真机通过。

Go 原生宿主使用 `native/wanx.Host`：Consumer 与签名/安全存储复用 SDK 接口；`Connect` 完成统一身份；`Request` 返回原生 `*http.Response`、保留字节流；`OpenSocket` 返回受原生会话约束的消息流。调用清单与 TS 客户端使用同一快照。离线发行保留 `native/upstream-sdk` 和 `native/upstream-core`，不需要再克隆私有仓库。

[Go 源码接入](docs/go.md)说明本地 module 引用、签名、安全存储与原生请求；[服务端配套要求](docs/backend-contract.md)列出匹配版本、新应用登记和后续真机验收所需的合同。

## 构建、测试与来源

```sh
npm ci
python3 tools/generate_runtime.py
python3 tools/build_native.py
make all
```

`make all` 执行类型、凭据负例、客户端运行测试、Go SDK/Core 测试与 vet、覆盖和来源检查。测试不调用付费模型、不读取现有账号或记忆、不连接真实盒子。验收结果见[验证记录](verification.json)；发行内容与 SHA256 见安装包旁的清单。

交付包可用 `npm pack --pack-destination artifacts` 生成，再执行 `python3 tools/check_consumer.py artifacts/centaurai-wanx-0.1.0-alpha.3.tgz` 验证全新目录的安装、类型、ESM/CJS 导入及 native host 调用。该消费者检查需要本机已有固定 npm 依赖缓存；它不发布到 npm。

来源固定为最新 Codeup `f0e9c63452e531b1f51024911637feae73738320` 的 Go SDK `0.2.0`、冻结 Core `0.1.1`，以及此前 WANX 平台 API 快照 `7d84a9973a2e18b7083d4b21d68fe6332123765c`。最新实际服务端若有新增/变更接口，需要导出对应 OpenAPI、重新生成客户端并重新验收；不能把这个旧快照当作未知生产版本的全部接口。

公司自有代码、文档和品牌遵循[公司专有许可](LICENSE)，未通过本项目授予开源或商业使用许可。第三方既有声明见[第三方说明](THIRD_PARTY_NOTICES.md)。

## 万象管理员与产品开发协议 V1

新增15项产品管理与应用域 profile 接口，真实客户端共472项HTTP绑定。请见[产品管理与工程生成](docs/applications.md)。`client.applications` 使用已有 transport / main IPC / Go白名单；新产品连接身份仍为pending，P2P不借用omnia-desktop。独立Node导出 `centaurai-wanx/project-generator` 可生成React/TypeScript/Electron工程并使用本地SDK包构建。

## WANX 浏览器界面复用

`0.1.0-alpha.3` 新增 `centaurai-wanx/browser`：导出纯 TypeScript 客户端、应用合同和工程模板，不引入 Node、Electron 或原生进程。浏览器由 WANX 既有同源 HTTP 适配器提供 `WanxTransport`，负责登录、JWT 更新、语言和断线取消；SDK 继续负责操作策略、参数序列化和应用门面。Node / Electron 入口保持原有行为。此入口不提供浏览器 P2P 或新的身份登记能力。

生成工程仍由已交付的私有 SDK `.tgz` 安装，不依赖公开 npm 发布。正式盒子和跨网络验收仍未完成。
