# centaurai-wanx：服务端配套与验收边界

本 SDK 的原生 API 清单来自 WANX 平台快照 `7d84a9973a2e18b7083d4b21d68fe6332123765c`。连接和统一身份来自最新 Codeup Go SDK 0.2.0；该仓库提供 SDK、协议与模拟服务，未定位到对应生产 WANX SSO 服务端实现。没有盒子时，可以验证客户端和合同，不能验证真实部署的全部模块行为。

| 配套项 | 当前客户端 | 服务端须满足 |
| --- | --- | --- |
| 原生业务模块 | 42 模块、457 公开 HTTP、31 记忆、7 WS | 同版路由、参数、权限与模块配置；新接口需导出新 OpenAPI |
| 统一身份 | challenge/grant/exchange、续租、登出、显式关联与 owner 初始化 | 实现 Go SDK 声明的 `/api/auth/nexusaos/*` 与 `/api/setup/nexusaos/initial-admin`；正确验证设备、P2P session、grant 与用户映射 |
| 应用身份 | 内置 `omnia-desktop` / `desktop_native` | 公司登记新的 applicationId/platform/scopes 后，签票、Core 会话、SSO grant 与设备服务须一致接受；不得简单复用别的身份 |
| 网络路径 | Direct-only / `nexusaos.p2p-app.v2` | 正确设备身份、受信信令/ICE、直连能力；Relay 尚需平台合同升级 |
| 上传 | 编码后请求最大 2 MiB、uploadStream=false | 大文件须另行批准分块上传/对象存储/请求流合同；不能只提高 SDK 限额 |
| 原生记忆 | 原生 atom/candidate/episode/entity/journal/terminal/portable 操作 | 原生用户与 Agent 资源权限；应用不另建记忆数据库 |

`api-policy-review.csv` 保留候选授权审查状态，表示接口并未因此得到公司生产授权。457 项绑定测试证明请求可以正确形成并通过本机 transport；它们不证明每个真实服务端模块的业务语义或权限均已通过验收。

SDK 名称统一为 `centaurai-wanx`；旧服务端包名 `octop`、字段和网络合同标识保留兼容。知君和未来应用的功能与记忆体验在应用层实现，账号/设备/P2P/原生 WANX 访问复用 SDK。

当具备盒子时，验收需要覆盖真实账号登录与恢复、设备选择与设备身份、跨网络直连、SSO 首次映射与显式关联、短租约续租/失效、原生记忆读写与隔离、上传/SSE/下载/七类 WS 以及目标 Electron/OS 安全存储。当前没有执行这些真机步骤，也没有进行生产发布。
