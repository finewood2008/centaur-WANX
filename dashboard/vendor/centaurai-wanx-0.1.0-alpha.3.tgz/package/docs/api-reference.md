# centaurai-wanx：完整 API 目录

以下是固定 WANX 平台快照的实际客户端方法。每个方法提供普通调用、`.stream` 和 `.events`；SSE 使用标注的 SSE 路由，二进制/大响应使用 `.stream`。原生参数结构见随包 `api-baseline/openapi.json` 与 `NativeOperations` 类型。3项 internal-mcp 接口排除。

共 42 个模块、457 项 HTTP 操作。模块归属采用原生 tags；操作别名来自原生 operationId，不另建业务模块。

## admin

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.admin.auditLog` | `GET /api/admin/audit-log` | parameters; HTTP |
| `sdk.modules.admin.getAutoBackupSettings` | `GET /api/admin/backup/auto` | parameters; HTTP |
| `sdk.modules.admin.putAutoBackupSettings` | `PUT /api/admin/backup/auto` | application/json; HTTP |
| `sdk.modules.admin.runAutoBackupNow` | `POST /api/admin/backup/auto/run` | parameters; HTTP |
| `sdk.modules.admin.createBackup` | `POST /api/admin/backup/create` | application/json; HTTP |
| `sdk.modules.admin.exportBackup` | `GET /api/admin/backup/export` | parameters; stream-or-binary |
| `sdk.modules.admin.removeBackupFile` | `DELETE /api/admin/backup/files/{filename}` | parameters; stream-or-binary |
| `sdk.modules.admin.downloadBackupFile` | `GET /api/admin/backup/files/{filename}` | parameters; stream-or-binary |
| `sdk.modules.admin.restoreBackupFile` | `POST /api/admin/backup/files/{filename}/restore` | parameters; HTTP |
| `sdk.modules.admin.importBackup` | `POST /api/admin/backup/import` | multipart/form-data; HTTP |
| `sdk.modules.admin.listBackups` | `GET /api/admin/backup/list` | parameters; HTTP |
| `sdk.modules.admin.getBackupStatus` | `GET /api/admin/backup/status` | parameters; HTTP |
| `sdk.modules.admin.metrics` | `GET /api/admin/metrics` | parameters; HTTP |
| `sdk.modules.admin.overview` | `GET /api/admin/overview` | parameters; HTTP |
| `sdk.modules.admin.adminListProviders` | `GET /api/admin/providers` | parameters; HTTP |
| `sdk.modules.admin.adminCreateProvider` | `POST /api/admin/providers` | application/json; HTTP |
| `sdk.modules.admin.codexOauthLogout` | `DELETE /api/admin/providers/codex-oauth` | parameters; HTTP |
| `sdk.modules.admin.codexOauthPending` | `GET /api/admin/providers/codex-oauth/pending/{state_id}` | parameters; HTTP |
| `sdk.modules.admin.codexOauthStart` | `POST /api/admin/providers/codex-oauth/start` | parameters; HTTP |
| `sdk.modules.admin.adminFetchProviderModels` | `POST /api/admin/providers/fetch-models` | application/json; HTTP |
| `sdk.modules.admin.adminTestProviderDraft` | `POST /api/admin/providers/test-draft` | application/json; HTTP |
| `sdk.modules.admin.adminDeleteProvider` | `DELETE /api/admin/providers/{provider_id}` | parameters; HTTP |
| `sdk.modules.admin.adminPatchProvider` | `PATCH /api/admin/providers/{provider_id}` | application/json; HTTP |
| `sdk.modules.admin.adminTestProvider` | `POST /api/admin/providers/{provider_id}/test` | application/json; HTTP |
| `sdk.modules.admin.listStorageBackends` | `GET /api/admin/storage-backends` | parameters; HTTP |
| `sdk.modules.admin.createStorageBackend` | `POST /api/admin/storage-backends` | application/json; HTTP |
| `sdk.modules.admin.probeStorageBackendConfig` | `POST /api/admin/storage-backends/probe` | application/json; HTTP |
| `sdk.modules.admin.deleteStorageBackend` | `DELETE /api/admin/storage-backends/{backend_id}` | parameters; HTTP |
| `sdk.modules.admin.patchStorageBackend` | `PATCH /api/admin/storage-backends/{backend_id}` | application/json; HTTP |
| `sdk.modules.admin.testStorageBackend` | `POST /api/admin/storage-backends/{backend_id}/test` | parameters; HTTP |
| `sdk.modules.admin.listStorageBackendTree` | `GET /api/admin/storage-backends/{backend_id}/tree` | parameters; HTTP |
| `sdk.modules.admin.adminExport` | `GET /api/admin/usage/export.xlsx` | parameters; stream-or-binary |
| `sdk.modules.admin.adminSummary` | `GET /api/admin/usage/summary` | parameters; HTTP |
| `sdk.modules.admin.adminListVoiceProviders` | `GET /api/admin/voice/providers` | parameters; HTTP |
| `sdk.modules.admin.adminCreateVoiceProvider` | `POST /api/admin/voice/providers` | application/json; HTTP |
| `sdk.modules.admin.adminTestVoiceConfiguration` | `POST /api/admin/voice/providers/test-configuration` | application/json; HTTP |
| `sdk.modules.admin.adminDeleteVoiceProvider` | `DELETE /api/admin/voice/providers/{provider_id}` | parameters; HTTP |
| `sdk.modules.admin.adminPatchVoiceProvider` | `PATCH /api/admin/voice/providers/{provider_id}` | application/json; HTTP |
| `sdk.modules.admin.adminTestVoiceProvider` | `POST /api/admin/voice/providers/{provider_id}/test` | application/json; HTTP |

## agentFiles

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.agentFiles.getHeartbeatConfig` | `GET /api/agents/{agent_id}/heartbeat-config` | parameters; HTTP |
| `sdk.modules.agentFiles.putHeartbeatConfig` | `PUT /api/agents/{agent_id}/heartbeat-config` | application/json; HTTP |
| `sdk.modules.agentFiles.listDailyMemory` | `GET /api/agents/{agent_id}/memory/daily` | parameters; HTTP |
| `sdk.modules.agentFiles.deleteDailyMemory` | `DELETE /api/agents/{agent_id}/memory/daily/{filename}` | parameters; HTTP |
| `sdk.modules.agentFiles.readDailyMemory` | `GET /api/agents/{agent_id}/memory/daily/{filename}` | parameters; HTTP |

## agents

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.agents.getGlobalAcpRunners` | `GET /api/acp` | parameters; HTTP |
| `sdk.modules.agents.putGlobalAcpRunners` | `PUT /api/acp` | application/json; HTTP |
| `sdk.modules.agents.deleteGlobalAcpRunner` | `DELETE /api/acp/{runner_name}` | parameters; HTTP |
| `sdk.modules.agents.getGlobalAcpRunner` | `GET /api/acp/{runner_name}` | parameters; HTTP |
| `sdk.modules.agents.putGlobalAcpRunner` | `PUT /api/acp/{runner_name}` | application/json; HTTP |
| `sdk.modules.agents.listAgents` | `GET /api/agents` | parameters; HTTP |
| `sdk.modules.agents.createAgent` | `POST /api/agents` | application/json; HTTP |
| `sdk.modules.agents.deleteAgent` | `DELETE /api/agents/{agent_id}` | parameters; HTTP |
| `sdk.modules.agents.getAgent` | `GET /api/agents/{agent_id}` | parameters; HTTP |
| `sdk.modules.agents.patchAgent` | `PATCH /api/agents/{agent_id}` | application/json; HTTP |
| `sdk.modules.agents.getAcpConfig` | `GET /api/agents/{agent_id}/acp` | parameters; HTTP |
| `sdk.modules.agents.putAcpConfig` | `PUT /api/agents/{agent_id}/acp` | application/json; HTTP |
| `sdk.modules.agents.putAcpToolToggle` | `PUT /api/agents/{agent_id}/acp/tool` | application/json; HTTP |
| `sdk.modules.agents.deleteAcpRunner` | `DELETE /api/agents/{agent_id}/acp/{runner_name}` | parameters; HTTP |
| `sdk.modules.agents.getAcpRunner` | `GET /api/agents/{agent_id}/acp/{runner_name}` | parameters; HTTP |
| `sdk.modules.agents.putAcpRunner` | `PUT /api/agents/{agent_id}/acp/{runner_name}` | application/json; HTTP |
| `sdk.modules.agents.deleteAgentAvatar` | `DELETE /api/agents/{agent_id}/avatar` | parameters; HTTP |
| `sdk.modules.agents.getAgentAvatar` | `GET /api/agents/{agent_id}/avatar` | parameters; HTTP |
| `sdk.modules.agents.uploadAgentAvatar` | `POST /api/agents/{agent_id}/avatar` | multipart/form-data; HTTP |
| `sdk.modules.agents.markAgentRead` | `POST /api/agents/{agent_id}/read` | parameters; HTTP |
| `sdk.modules.agents.reloadAgent` | `POST /api/agents/{agent_id}/reload` | parameters; HTTP |
| `sdk.modules.agents.startAgent` | `POST /api/agents/{agent_id}/start` | parameters; HTTP |
| `sdk.modules.agents.agentStatus` | `GET /api/agents/{agent_id}/status` | parameters; HTTP |
| `sdk.modules.agents.stopAgent` | `POST /api/agents/{agent_id}/stop` | parameters; HTTP |
| `sdk.modules.agents.getToolSettings` | `GET /api/agents/{agent_id}/tool-settings` | parameters; HTTP |
| `sdk.modules.agents.putToolSettings` | `PUT /api/agents/{agent_id}/tool-settings` | application/json; HTTP |
| `sdk.modules.agents.patchToolSetting` | `PATCH /api/agents/{agent_id}/tool-settings/{tool_name}` | application/json; HTTP |

## auth

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.auth.getCaptcha` | `GET /api/auth/captcha` | parameters; HTTP |
| `sdk.modules.auth.changePassword` | `POST /api/auth/change-password` | application/json; HTTP |
| `sdk.modules.auth.redeemInvite` | `POST /api/auth/invite/redeem` | application/json; HTTP |
| `sdk.modules.auth.validateInvite` | `POST /api/auth/invite/validate` | application/json; HTTP |
| `sdk.modules.auth.login` | `POST /api/auth/login` | application/json; HTTP |
| `sdk.modules.auth.logout` | `POST /api/auth/logout` | parameters; HTTP |
| `sdk.modules.auth.me` | `GET /api/auth/me` | parameters; HTTP |
| `sdk.modules.auth.updateMe` | `PATCH /api/auth/me` | application/json; HTTP |
| `sdk.modules.auth.deleteMyAvatar` | `DELETE /api/auth/me/avatar` | parameters; HTTP |
| `sdk.modules.auth.uploadMyAvatar` | `POST /api/auth/me/avatar` | multipart/form-data; HTTP |
| `sdk.modules.auth.oauthBindStart` | `POST /api/auth/oauth/bind/start` | application/json; HTTP |
| `sdk.modules.auth.oauthCallback` | `GET /api/auth/oauth/callback` | parameters; HTTP |
| `sdk.modules.auth.oauthExchange` | `POST /api/auth/oauth/exchange` | application/json; HTTP |
| `sdk.modules.auth.getOauthProvider` | `GET /api/auth/oauth/providers/{kind}` | parameters; HTTP |
| `sdk.modules.auth.putOauthProvider` | `PUT /api/auth/oauth/providers/{kind}` | application/json; HTTP |
| `sdk.modules.auth.testOauthProvider` | `POST /api/auth/oauth/providers/{kind}/test` | parameters; HTTP |
| `sdk.modules.auth.oauthStart` | `POST /api/auth/oauth/start` | application/json; HTTP |
| `sdk.modules.auth.oauthStatus` | `GET /api/auth/oauth/status` | parameters; HTTP |
| `sdk.modules.auth.oauthUnbind` | `POST /api/auth/oauth/unbind` | application/json; HTTP |
| `sdk.modules.auth.oidcCallback` | `GET /api/auth/oidc/callback` | parameters; HTTP |
| `sdk.modules.auth.oidcConfig` | `GET /api/auth/oidc/config` | parameters; HTTP |
| `sdk.modules.auth.putOidcConfig` | `PUT /api/auth/oidc/config` | application/json; HTTP |
| `sdk.modules.auth.testOidcConfig` | `POST /api/auth/oidc/config/test` | parameters; HTTP |
| `sdk.modules.auth.oidcExchange` | `POST /api/auth/oidc/exchange` | application/json; HTTP |
| `sdk.modules.auth.oidcStart` | `POST /api/auth/oidc/start` | application/json; HTTP |
| `sdk.modules.auth.oidcStatus` | `GET /api/auth/oidc/status` | parameters; HTTP |
| `sdk.modules.auth.getPreferences` | `GET /api/preferences` | parameters; HTTP |
| `sdk.modules.auth.patchPreferences` | `PATCH /api/preferences` | application/json; HTTP |

## browser

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.browser.envStatus` | `GET /api/browser/env-status` | parameters; HTTP |
| `sdk.modules.browser.listHarnessSessions` | `GET /api/browser/harness-sessions` | parameters; HTTP |
| `sdk.modules.browser.install` | `POST /api/browser/install` | parameters; sse |
| `sdk.modules.browser.replayRecording` | `POST /api/browser/record-replay/replay` | application/json; HTTP |
| `sdk.modules.browser.getSkillContent` | `POST /api/browser/record-replay/skill-content` | application/json; HTTP |
| `sdk.modules.browser.recordStart` | `POST /api/browser/record-replay/start` | application/json; HTTP |
| `sdk.modules.browser.recordStatus` | `GET /api/browser/record-replay/status` | parameters; HTTP |
| `sdk.modules.browser.recordStop` | `POST /api/browser/record-replay/stop` | application/json; HTTP |
| `sdk.modules.browser.recordStopAndGenerateSkill` | `POST /api/browser/record-replay/stop-and-generate-skill` | application/json; HTTP |
| `sdk.modules.browser.handoff` | `POST /api/browser/sessions/{session_id}/handoff` | application/json; HTTP |
| `sdk.modules.browser.shutdownBrowser` | `POST /api/browser/shutdown` | parameters; HTTP |
| `sdk.modules.browser.uninstallBrowser` | `POST /api/browser/uninstall` | parameters; sse |

## channels

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.channels.listChannels` | `GET /api/agents/{agent_id}/channels` | parameters; HTTP |
| `sdk.modules.channels.createChannel` | `POST /api/agents/{agent_id}/channels` | application/json; HTTP |
| `sdk.modules.channels.dingtalkQrcodeGenerate` | `POST /api/agents/{agent_id}/channels/dingtalk/qrcode/generate` | parameters; HTTP |
| `sdk.modules.channels.dingtalkQrcodePoll` | `POST /api/agents/{agent_id}/channels/dingtalk/qrcode/poll` | application/json; HTTP |
| `sdk.modules.channels.feishuBotCreatorPoll` | `POST /api/agents/{agent_id}/channels/feishu/bot-creator/poll` | parameters; HTTP |
| `sdk.modules.channels.feishuBotCreatorStart` | `POST /api/agents/{agent_id}/channels/feishu/bot-creator/start` | application/json; HTTP |
| `sdk.modules.channels.feishuBotCreatorStop` | `POST /api/agents/{agent_id}/channels/feishu/bot-creator/stop` | parameters; HTTP |
| `sdk.modules.channels.probeChannelConfig` | `POST /api/agents/{agent_id}/channels/probe` | application/json; HTTP |
| `sdk.modules.channels.qqQrcodeGenerate` | `POST /api/agents/{agent_id}/channels/qq/qrcode/generate` | parameters; HTTP |
| `sdk.modules.channels.qqQrcodePoll` | `POST /api/agents/{agent_id}/channels/qq/qrcode/poll` | application/json; HTTP |
| `sdk.modules.channels.wecomQrcodeGenerate` | `POST /api/agents/{agent_id}/channels/wecom/qrcode/generate` | parameters; HTTP |
| `sdk.modules.channels.wecomQrcodePoll` | `POST /api/agents/{agent_id}/channels/wecom/qrcode/poll` | application/json; HTTP |
| `sdk.modules.channels.weixinQrcodeGenerate` | `POST /api/agents/{agent_id}/channels/weixin/qrcode/generate` | parameters; HTTP |
| `sdk.modules.channels.weixinQrcodePoll` | `POST /api/agents/{agent_id}/channels/weixin/qrcode/poll` | application/json; HTTP |
| `sdk.modules.channels.yuanbaoBotCreatorPoll` | `POST /api/agents/{agent_id}/channels/yuanbao/bot-creator/poll` | parameters; HTTP |
| `sdk.modules.channels.yuanbaoBotCreatorStart` | `POST /api/agents/{agent_id}/channels/yuanbao/bot-creator/start` | application/json; HTTP |
| `sdk.modules.channels.yuanbaoBotCreatorStop` | `POST /api/agents/{agent_id}/channels/yuanbao/bot-creator/stop` | parameters; HTTP |
| `sdk.modules.channels.deleteChannel` | `DELETE /api/agents/{agent_id}/channels/{channel_id}` | parameters; HTTP |
| `sdk.modules.channels.getChannel` | `GET /api/agents/{agent_id}/channels/{channel_id}` | parameters; HTTP |
| `sdk.modules.channels.patchChannel` | `PATCH /api/agents/{agent_id}/channels/{channel_id}` | application/json; HTTP |
| `sdk.modules.channels.testChannel` | `POST /api/agents/{agent_id}/channels/{channel_id}/test` | parameters; HTTP |

## chat

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.chat.resumeHitl` | `POST /api/agents/{agent_id}/chat/hitl/resume` | application/json; sse |
| `sdk.modules.chat.polishPrompt` | `POST /api/agents/{agent_id}/chat/polish` | application/json; HTTP |
| `sdk.modules.chat.getChatWelcome` | `GET /api/agents/{agent_id}/chat/welcome` | parameters; HTTP |
| `sdk.modules.chat.startHistoryMigration` | `POST /api/agents/{agent_id}/history-migration/start` | parameters; HTTP |
| `sdk.modules.chat.getHistoryMigrationStatus` | `GET /api/agents/{agent_id}/history-migration/status` | parameters; HTTP |
| `sdk.modules.chat.rebindSession` | `PATCH /api/agents/{agent_id}/session` | application/json; HTTP |
| `sdk.modules.chat.listThreads` | `GET /api/agents/{agent_id}/threads` | parameters; HTTP |
| `sdk.modules.chat.createThread` | `POST /api/agents/{agent_id}/threads` | parameters; HTTP |
| `sdk.modules.chat.deleteThread` | `DELETE /api/agents/{agent_id}/threads/{thread_id}` | parameters; HTTP |
| `sdk.modules.chat.patchThread` | `PATCH /api/agents/{agent_id}/threads/{thread_id}` | application/json; HTTP |
| `sdk.modules.chat.getThreadContextUsage` | `GET /api/agents/{agent_id}/threads/{thread_id}/context-usage` | parameters; HTTP |
| `sdk.modules.chat.forkThread` | `POST /api/agents/{agent_id}/threads/{thread_id}/fork` | application/json; HTTP |
| `sdk.modules.chat.getThreadHistory` | `GET /api/agents/{agent_id}/threads/{thread_id}/history` | parameters; HTTP |
| `sdk.modules.chat.exportHistory` | `GET /api/agents/{agent_id}/threads/{thread_id}/history/export` | parameters; HTTP |
| `sdk.modules.chat.markThreadRead` | `POST /api/agents/{agent_id}/threads/{thread_id}/read` | parameters; HTTP |
| `sdk.modules.chat.getThreadTrajectory` | `GET /api/agents/{agent_id}/threads/{thread_id}/trajectory` | parameters; HTTP |
| `sdk.modules.chat.getTrajectoryEvent` | `GET /api/agents/{agent_id}/threads/{thread_id}/trajectory/events/{event_id}` | parameters; HTTP |
| `sdk.modules.chat.exportThreadTrajectory` | `GET /api/agents/{agent_id}/threads/{thread_id}/trajectory/export` | parameters; stream-or-binary |
| `sdk.modules.chat.getTrajectoryMetrics` | `GET /api/agents/{agent_id}/threads/{thread_id}/trajectory/metrics` | parameters; HTTP |
| `sdk.modules.chat.streamThreadTrajectory` | `GET /api/agents/{agent_id}/threads/{thread_id}/trajectory/stream` | parameters; sse |
| `sdk.modules.chat.uploadAttachment` | `POST /api/agents/{agent_id}/upload` | multipart/form-data; HTTP |

## connectors

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.connectors.listInstances` | `GET /api/connector-instances` | parameters; HTTP |
| `sdk.modules.connectors.createInstance` | `POST /api/connector-instances` | application/json; HTTP |
| `sdk.modules.connectors.deleteInstance` | `DELETE /api/connector-instances/{instance_id}` | parameters; HTTP |
| `sdk.modules.connectors.getInstance` | `GET /api/connector-instances/{instance_id}` | parameters; HTTP |
| `sdk.modules.connectors.patchInstance` | `PATCH /api/connector-instances/{instance_id}` | application/json; HTTP |
| `sdk.modules.connectors.feishuCliUserAuthCompleteInstance` | `POST /api/connector-instances/{instance_id}/feishu-user-auth/complete` | application/json; HTTP |
| `sdk.modules.connectors.feishuCliUserAuthStartInstance` | `POST /api/connector-instances/{instance_id}/feishu-user-auth/start` | parameters; HTTP |
| `sdk.modules.connectors.refreshInstance` | `POST /api/connector-instances/{instance_id}/refresh` | parameters; HTTP |
| `sdk.modules.connectors.testInstance` | `POST /api/connector-instances/{instance_id}/test` | parameters; HTTP |
| `sdk.modules.connectors.authAuthorizeUrl` | `GET /api/connectors/auth/{kind}/authorize-url` | parameters; HTTP |
| `sdk.modules.connectors.authExchangeCode` | `POST /api/connectors/auth/{kind}/exchange-code` | application/json; HTTP |
| `sdk.modules.connectors.authInfo` | `GET /api/connectors/auth/{kind}/info` | parameters; HTTP |
| `sdk.modules.connectors.getCatalog` | `GET /api/connectors/catalog` | parameters; HTTP |
| `sdk.modules.connectors.getCustomMcp` | `GET /api/connectors/custom-mcp` | parameters; HTTP |
| `sdk.modules.connectors.putCustomMcp` | `PUT /api/connectors/custom-mcp` | application/json; HTTP |
| `sdk.modules.connectors.patchCustomMcpServer` | `PATCH /api/connectors/custom-mcp/servers/{server_name}` | application/json; HTTP |
| `sdk.modules.connectors.testCustomMcp` | `POST /api/connectors/custom-mcp/test` | application/json; HTTP |
| `sdk.modules.connectors.feishuCliUserAuthComplete` | `POST /api/connectors/feishu-cli/user-auth/complete` | application/json; HTTP |
| `sdk.modules.connectors.feishuCliUserAuthStart` | `POST /api/connectors/feishu-cli/user-auth/start` | application/json; HTTP |
| `sdk.modules.connectors.oauthCallback` | `GET /api/connectors/oauth/callback` | parameters; HTTP |
| `sdk.modules.connectors.oauthPending` | `GET /api/connectors/oauth/pending/{state_id}` | parameters; HTTP |
| `sdk.modules.connectors.oauthStartUnified` | `POST /api/connectors/oauth/start` | application/json; HTTP |
| `sdk.modules.connectors.oauthStartLegacy` | `POST /api/connectors/oauth/{kind}/start` | application/json; HTTP |
| `sdk.modules.connectors.testCredentials` | `POST /api/connectors/test-credentials` | application/json; HTTP |
| `sdk.modules.connectors.detectWeknoraOnOctopHost` | `GET /api/connectors/weknora/detect-local` | parameters; HTTP |
| `sdk.modules.connectors.connectorCliStatus` | `GET /api/connectors/{kind}/cli-status` | parameters; HTTP |
| `sdk.modules.connectors.connectorInstallCli` | `POST /api/connectors/{kind}/install-cli` | parameters; HTTP |

## cron

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.cron.listCron` | `GET /api/agents/{agent_id}/cron` | parameters; HTTP |
| `sdk.modules.cron.createCron` | `POST /api/agents/{agent_id}/cron` | application/json; HTTP |
| `sdk.modules.cron.cronExamples` | `GET /api/agents/{agent_id}/cron/examples` | parameters; HTTP |
| `sdk.modules.cron.deleteCron` | `DELETE /api/agents/{agent_id}/cron/{cron_id}` | parameters; HTTP |
| `sdk.modules.cron.getCron` | `GET /api/agents/{agent_id}/cron/{cron_id}` | parameters; HTTP |
| `sdk.modules.cron.patchCron` | `PATCH /api/agents/{agent_id}/cron/{cron_id}` | application/json; HTTP |
| `sdk.modules.cron.runNow` | `POST /api/agents/{agent_id}/cron/{cron_id}/run-now` | parameters; HTTP |
| `sdk.modules.cron.cronSettings` | `GET /api/cron/settings` | parameters; HTTP |

## desktop

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.desktop.getDesktopGeometry` | `GET /api/desktop/geometry` | parameters; HTTP |
| `sdk.modules.desktop.setDesktopGeometry` | `POST /api/desktop/geometry` | application/json; HTTP |
| `sdk.modules.desktop.installDesktop` | `POST /api/desktop/install` | parameters; sse |
| `sdk.modules.desktop.getDesktopStatus` | `GET /api/desktop/status` | parameters; HTTP |
| `sdk.modules.desktop.uninstallDesktop` | `POST /api/desktop/uninstall` | parameters; sse |

## envs

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.envs.listEnvs` | `GET /api/envs` | parameters; HTTP |
| `sdk.modules.envs.batchSaveEnvs` | `PUT /api/envs` | application/json; HTTP |
| `sdk.modules.envs.deleteEnv` | `DELETE /api/envs/{key}` | parameters; HTTP |

## experts

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.experts.createAgentFromExpert` | `POST /api/agents/from-expert/{expert_id}` | application/json; HTTP |
| `sdk.modules.experts.publishAgentExpert` | `POST /api/agents/{agent_id}/publish-expert` | application/json; HTTP |
| `sdk.modules.experts.listExperts` | `GET /api/experts` | parameters; HTTP |
| `sdk.modules.experts.listExpertHub` | `GET /api/experts/hub` | parameters; HTTP |
| `sdk.modules.experts.getExpertHubItem` | `GET /api/experts/hub/{slug}` | parameters; HTTP |
| `sdk.modules.experts.installExpertHubItem` | `POST /api/experts/hub/{slug}/install` | application/json; HTTP |
| `sdk.modules.experts.listPublishedExperts` | `GET /api/experts/published` | parameters; HTTP |
| `sdk.modules.experts.unpublishExpert` | `DELETE /api/experts/published/{expert_id}` | parameters; HTTP |
| `sdk.modules.experts.getPublishedExpert` | `GET /api/experts/published/{expert_id}` | parameters; HTTP |
| `sdk.modules.experts.getPublishedExpertAvatar` | `GET /api/experts/published/{expert_id}/avatar` | parameters; HTTP |
| `sdk.modules.experts.installPublishedExpert` | `POST /api/experts/published/{expert_id}/install` | application/json; HTTP |
| `sdk.modules.experts.refreshPublishedExpert` | `POST /api/experts/published/{expert_id}/refresh` | application/json; HTTP |
| `sdk.modules.experts.getExpert` | `GET /api/experts/{expert_id}` | parameters; HTTP |

## filesystem

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.filesystem.filesystemDefaults` | `GET /api/filesystem/defaults` | parameters; HTTP |
| `sdk.modules.filesystem.listHostDirs` | `GET /api/filesystem/dirs` | parameters; HTTP |
| `sdk.modules.filesystem.getDockerStatus` | `GET /api/filesystem/docker-status` | parameters; HTTP |
| `sdk.modules.filesystem.ensureBwrap` | `POST /api/filesystem/ensure-bwrap` | parameters; HTTP |
| `sdk.modules.filesystem.postEnsureDocker` | `POST /api/filesystem/ensure-docker` | parameters; HTTP |
| `sdk.modules.filesystem.mkdirHostDir` | `POST /api/filesystem/mkdir` | application/json; HTTP |
| `sdk.modules.filesystem.probeHostDir` | `POST /api/filesystem/probe` | application/json; HTTP |
| `sdk.modules.filesystem.renameHostDirectory` | `POST /api/filesystem/rename` | application/json; HTTP |

## health

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.health.health` | `GET /api/health` | parameters; HTTP |

## i18n

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.i18n.getSkillLabels` | `GET /api/i18n/skills` | parameters; HTTP |
| `sdk.modules.i18n.getToolLabels` | `GET /api/i18n/tools` | parameters; HTTP |

## knowledge

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.knowledge.listBases` | `GET /api/knowledge-bases` | parameters; HTTP |
| `sdk.modules.knowledge.createBase` | `POST /api/knowledge-bases` | application/json; HTTP |
| `sdk.modules.knowledge.capability` | `GET /api/knowledge-bases/capability` | parameters; HTTP |
| `sdk.modules.knowledge.defaultOpenBases` | `GET /api/knowledge-bases/default-open` | parameters; HTTP |
| `sdk.modules.knowledge.embeddingOptions` | `GET /api/knowledge-bases/embedding-options` | parameters; HTTP |
| `sdk.modules.knowledge.putFeature` | `PUT /api/knowledge-bases/feature` | application/json; HTTP |
| `sdk.modules.knowledge.ocrOptions` | `GET /api/knowledge-bases/ocr-options` | parameters; HTTP |
| `sdk.modules.knowledge.activateOnnxService` | `POST /api/knowledge-bases/onnx-activate` | application/json; HTTP |
| `sdk.modules.knowledge.startOnnxDownload` | `POST /api/knowledge-bases/onnx-download` | application/json; HTTP |
| `sdk.modules.knowledge.onnxDownloadStatus` | `GET /api/knowledge-bases/onnx-download-status` | parameters; HTTP |
| `sdk.modules.knowledge.testOnnxModel` | `POST /api/knowledge-bases/onnx-test` | application/json; HTTP |
| `sdk.modules.knowledge.deleteBase` | `DELETE /api/knowledge-bases/{kb_id}` | parameters; HTTP |
| `sdk.modules.knowledge.getBase` | `GET /api/knowledge-bases/{kb_id}` | parameters; HTTP |
| `sdk.modules.knowledge.updateBase` | `PATCH /api/knowledge-bases/{kb_id}` | application/json; HTTP |
| `sdk.modules.knowledge.listDocuments` | `GET /api/knowledge-bases/{kb_id}/documents` | parameters; HTTP |
| `sdk.modules.knowledge.uploadDocument` | `POST /api/knowledge-bases/{kb_id}/documents` | multipart/form-data; HTTP |
| `sdk.modules.knowledge.createTextDocument` | `POST /api/knowledge-bases/{kb_id}/documents/text` | application/json; HTTP |
| `sdk.modules.knowledge.deleteDocument` | `DELETE /api/knowledge-bases/{kb_id}/documents/{doc_id}` | parameters; HTTP |
| `sdk.modules.knowledge.getTextDocument` | `GET /api/knowledge-bases/{kb_id}/documents/{doc_id}/content` | parameters; HTTP |
| `sdk.modules.knowledge.updateTextDocument` | `PUT /api/knowledge-bases/{kb_id}/documents/{doc_id}/content` | application/json; HTTP |
| `sdk.modules.knowledge.downloadDocumentFile` | `GET /api/knowledge-bases/{kb_id}/documents/{doc_id}/file` | parameters; stream-or-binary |
| `sdk.modules.knowledge.previewDocument` | `GET /api/knowledge-bases/{kb_id}/documents/{doc_id}/preview` | parameters; HTTP |
| `sdk.modules.knowledge.reindexDocument` | `POST /api/knowledge-bases/{kb_id}/documents/{doc_id}/reindex` | parameters; HTTP |
| `sdk.modules.knowledge.renameDocument` | `POST /api/knowledge-bases/{kb_id}/documents/{doc_id}/rename` | application/json; HTTP |
| `sdk.modules.knowledge.createFolder` | `POST /api/knowledge-bases/{kb_id}/folders` | application/json; HTTP |
| `sdk.modules.knowledge.reindexBase` | `POST /api/knowledge-bases/{kb_id}/reindex` | parameters; HTTP |

## mbti

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.mbti.applyType` | `POST /api/mbti/apply` | application/json; HTTP |
| `sdk.modules.mbti.getCurrentMbti` | `GET /api/mbti/current` | parameters; HTTP |
| `sdk.modules.mbti.getPersonaPreview` | `GET /api/mbti/preview/{code}` | parameters; HTTP |
| `sdk.modules.mbti.getTestQuestions` | `GET /api/mbti/test/questions` | parameters; HTTP |
| `sdk.modules.mbti.submitTest` | `POST /api/mbti/test/submit` | application/json; HTTP |
| `sdk.modules.mbti.listTypes` | `GET /api/mbti/types` | parameters; HTTP |
| `sdk.modules.mbti.getType` | `GET /api/mbti/types/{code}` | parameters; HTTP |

## memory

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.memory.createAtom` | `POST /api/agents/{agent_id}/memory/atoms` | application/json; HTTP |
| `sdk.modules.memory.listAtoms` | `POST /api/agents/{agent_id}/memory/atoms/list` | application/json; HTTP |
| `sdk.modules.memory.getAtom` | `GET /api/agents/{agent_id}/memory/atoms/{atom_id}` | parameters; HTTP |
| `sdk.modules.memory.deprecateAtom` | `POST /api/agents/{agent_id}/memory/atoms/{atom_id}:deprecate` | application/json; HTTP |
| `sdk.modules.memory.replaceAtom` | `POST /api/agents/{agent_id}/memory/atoms/{atom_id}:replace` | application/json; HTTP |
| `sdk.modules.memory.listCandidates` | `POST /api/agents/{agent_id}/memory/candidates/list` | application/json; HTTP |
| `sdk.modules.memory.getCandidate` | `GET /api/agents/{agent_id}/memory/candidates/{candidate_id}` | parameters; HTTP |
| `sdk.modules.memory.promoteCandidate` | `POST /api/agents/{agent_id}/memory/candidates/{candidate_id}:promote` | parameters; HTTP |
| `sdk.modules.memory.rejectCandidate` | `POST /api/agents/{agent_id}/memory/candidates/{candidate_id}:reject` | application/json; HTTP |
| `sdk.modules.memory.listEntities` | `POST /api/agents/{agent_id}/memory/entities/list` | application/json; HTTP |
| `sdk.modules.memory.getEntity` | `GET /api/agents/{agent_id}/memory/entities/{entity_id}` | parameters; HTTP |
| `sdk.modules.memory.listEpisodes` | `POST /api/agents/{agent_id}/memory/episodes/list` | application/json; HTTP |
| `sdk.modules.memory.getEpisode` | `GET /api/agents/{agent_id}/memory/episodes/{episode_id}` | parameters; HTTP |
| `sdk.modules.memory.getExtractConfig` | `GET /api/agents/{agent_id}/memory/extract-config` | parameters; HTTP |
| `sdk.modules.memory.putExtractConfig` | `PUT /api/agents/{agent_id}/memory/extract-config` | application/json; HTTP |
| `sdk.modules.memory.listJournal` | `POST /api/agents/{agent_id}/memory/journal/list` | application/json; HTTP |
| `sdk.modules.memory.recentJournal` | `GET /api/agents/{agent_id}/memory/journal/recent` | parameters; HTTP |
| `sdk.modules.memory.adoptAgentMemory` | `POST /api/agents/{agent_id}/memory/portable/adopt` | multipart/form-data; HTTP |
| `sdk.modules.memory.doctorAgentMemory` | `POST /api/agents/{agent_id}/memory/portable/doctor` | multipart/form-data; HTTP |
| `sdk.modules.memory.packAgentMemory` | `POST /api/agents/{agent_id}/memory/portable/pack` | parameters; stream-or-binary |
| `sdk.modules.memory.listRawEvents` | `POST /api/agents/{agent_id}/memory/raw_events/list` | application/json; HTTP |
| `sdk.modules.memory.getRawEvent` | `GET /api/agents/{agent_id}/memory/raw_events/{event_id}` | parameters; HTTP |
| `sdk.modules.memory.statsAtomKinds` | `GET /api/agents/{agent_id}/memory/stats/atom_kinds` | parameters; HTTP |
| `sdk.modules.memory.statsCounts` | `GET /api/agents/{agent_id}/memory/stats/counts` | parameters; HTTP |
| `sdk.modules.memory.statsGrowth` | `GET /api/agents/{agent_id}/memory/stats/growth` | parameters; HTTP |
| `sdk.modules.memory.terminalAboutMe` | `GET /api/agents/{agent_id}/memory/terminal/about_me` | parameters; HTTP |
| `sdk.modules.memory.terminalCurrentFocus` | `GET /api/agents/{agent_id}/memory/terminal/current_focus` | parameters; HTTP |
| `sdk.modules.memory.terminalEntities` | `GET /api/agents/{agent_id}/memory/terminal/entities` | parameters; HTTP |
| `sdk.modules.memory.terminalRecentStories` | `GET /api/agents/{agent_id}/memory/terminal/recent_stories` | parameters; HTTP |
| `sdk.modules.memory.terminalThingsYouToldMe` | `GET /api/agents/{agent_id}/memory/terminal/things_you_told_me` | parameters; HTTP |
| `sdk.modules.memory.listPortableSources` | `GET /api/memory/portable/sources` | parameters; HTTP |

## mobile

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.mobile.getAgentControl` | `GET /api/mobile/agent-control` | parameters; HTTP |
| `sdk.modules.mobile.putAgentControl` | `PUT /api/mobile/agent-control` | application/json; HTTP |
| `sdk.modules.mobile.getMobileDeviceInfo` | `GET /api/mobile/devices/{device}/info` | parameters; HTTP |
| `sdk.modules.mobile.installMobile` | `POST /api/mobile/install` | parameters; sse |
| `sdk.modules.mobile.getMobileStatus` | `GET /api/mobile/status` | parameters; HTTP |

## observability

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.observability.getLangfuseConfig` | `GET /api/admin/observability/langfuse` | parameters; HTTP |
| `sdk.modules.observability.putLangfuseConfig` | `PUT /api/admin/observability/langfuse` | application/json; HTTP |
| `sdk.modules.observability.testLangfuseConnection` | `POST /api/admin/observability/langfuse/test` | application/json; HTTP |

## ollama

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.ollama.listOllamaModels` | `GET /api/ollama-models` | parameters; HTTP |
| `sdk.modules.ollama.downloadOllamaModel` | `POST /api/ollama-models/download` | application/json; HTTP |
| `sdk.modules.ollama.getOllamaDownloadStatus` | `GET /api/ollama-models/download-status` | parameters; HTTP |
| `sdk.modules.ollama.cancelOllamaDownload` | `DELETE /api/ollama-models/download/{task_id}` | parameters; HTTP |
| `sdk.modules.ollama.getOllamaService` | `GET /api/ollama-models/service` | parameters; HTTP |
| `sdk.modules.ollama.putOllamaService` | `PUT /api/ollama-models/service` | application/json; HTTP |
| `sdk.modules.ollama.deleteOllamaModel` | `DELETE /api/ollama-models/{name}` | parameters; HTTP |

## onnx

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.onnx.getCatalog` | `GET /api/onnx-models/catalog` | parameters; HTTP |
| `sdk.modules.onnx.putConfig` | `PUT /api/onnx-models/config` | application/json; HTTP |
| `sdk.modules.onnx.postDownload` | `POST /api/onnx-models/download` | application/json; HTTP |
| `sdk.modules.onnx.getDownloadStatus` | `GET /api/onnx-models/download-status` | parameters; HTTP |
| `sdk.modules.onnx.deleteLocalModel` | `DELETE /api/onnx-models/local/{model_name}` | parameters; HTTP |
| `sdk.modules.onnx.getModelMeta` | `GET /api/onnx-models/models/{model_name}/meta` | parameters; HTTP |
| `sdk.modules.onnx.getStatus` | `GET /api/onnx-models/status` | parameters; HTTP |
| `sdk.modules.onnx.postTest` | `POST /api/onnx-models/test` | application/json; HTTP |

## plugins

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.plugins.listPlugins` | `GET /api/plugins` | parameters; HTTP |
| `sdk.modules.plugins.listAgentPlugins` | `GET /api/plugins/agents/{agent_id}` | parameters; HTTP |
| `sdk.modules.plugins.patchAgentPlugins` | `PATCH /api/plugins/agents/{agent_id}` | application/json; HTTP |
| `sdk.modules.plugins.listAgentPluginTools` | `GET /api/plugins/agents/{agent_id}/tools` | parameters; HTTP |
| `sdk.modules.plugins.patchAgentPluginTools` | `PATCH /api/plugins/agents/{agent_id}/tools` | application/json; HTTP |
| `sdk.modules.plugins.installPlugin` | `POST /api/plugins/install` | application/json; HTTP |
| `sdk.modules.plugins.listMarketPlugins` | `GET /api/plugins/market` | parameters; HTTP |
| `sdk.modules.plugins.installMarketPlugin` | `POST /api/plugins/market/{plugin_id}/install` | parameters; HTTP |
| `sdk.modules.plugins.getMarketPluginUiAsset` | `GET /api/plugins/market/{plugin_id}/ui/{file_path}` | parameters; stream-or-binary |
| `sdk.modules.plugins.reloadPlugins` | `POST /api/plugins/reload` | parameters; HTTP |
| `sdk.modules.plugins.uploadPlugin` | `POST /api/plugins/upload` | multipart/form-data; HTTP |
| `sdk.modules.plugins.uninstallPlugin` | `DELETE /api/plugins/{plugin_id}` | parameters; HTTP |
| `sdk.modules.plugins.patchPlugin` | `PATCH /api/plugins/{plugin_id}` | application/json; HTTP |
| `sdk.modules.plugins.getPluginUiAsset` | `GET /api/plugins/{plugin_id}/ui/{file_path}` | parameters; stream-or-binary |

## proactiveCare

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.proactiveCare.getProactiveCareConfig` | `GET /api/agents/{agent_id}/proactive-care` | parameters; HTTP |
| `sdk.modules.proactiveCare.putProactiveCareConfig` | `PUT /api/agents/{agent_id}/proactive-care` | application/json; HTTP |

## providers

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.providers.getMediaGenerationSettings` | `GET /api/admin/media-generation` | parameters; HTTP |
| `sdk.modules.providers.putMediaGenerationSettings` | `PUT /api/admin/media-generation` | application/json; HTTP |
| `sdk.modules.providers.listMediaProviderPresets` | `GET /api/admin/media-generation/presets` | parameters; HTTP |
| `sdk.modules.providers.testMediaGenerationProvider` | `POST /api/admin/media-generation/test` | application/json; HTTP |
| `sdk.modules.providers.listProviders` | `GET /api/providers` | parameters; HTTP |
| `sdk.modules.providers.getActiveModel` | `GET /api/providers/active-model` | parameters; HTTP |
| `sdk.modules.providers.setActiveModel` | `PUT /api/providers/active-model` | application/json; HTTP |
| `sdk.modules.providers.listProviderPresets` | `GET /api/providers/presets` | parameters; HTTP |
| `sdk.modules.providers.listResolvedModels` | `GET /api/providers/resolved` | parameters; HTTP |

## search

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.search.testSearchProvider` | `POST /api/search/{provider_id}/test` | application/json; HTTP |

## security

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.security.getSecurityPolicy` | `GET /api/admin/security` | parameters; HTTP |
| `sdk.modules.security.putSecurityPolicy` | `PUT /api/admin/security` | application/json; HTTP |
| `sdk.modules.security.getSecurityDefaults` | `GET /api/admin/security/defaults` | parameters; HTTP |
| `sdk.modules.security.getToolGuardRules` | `GET /api/admin/security/tool-guard/rules` | parameters; HTTP |
| `sdk.modules.security.getToolGuardRulesRaw` | `GET /api/admin/security/tool-guard/rules/raw` | parameters; HTTP |
| `sdk.modules.security.putToolGuardRulesRaw` | `PUT /api/admin/security/tool-guard/rules/raw` | application/json; HTTP |
| `sdk.modules.security.postToolGuardRulesReset` | `POST /api/admin/security/tool-guard/rules/reset` | parameters; HTTP |

## settings

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.settings.getCapabilities` | `GET /api/settings/capabilities` | parameters; HTTP |
| `sdk.modules.settings.getCaptchaSettings` | `GET /api/settings/captcha` | parameters; HTTP |
| `sdk.modules.settings.putCaptchaSettings` | `PUT /api/settings/captcha` | application/json; HTTP |
| `sdk.modules.settings.getTimezoneSettings` | `GET /api/settings/timezone` | parameters; HTTP |
| `sdk.modules.settings.getUploadSettings` | `GET /api/settings/upload` | parameters; HTTP |

## setup

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.setup.beginSetup` | `POST /api/setup/begin` | parameters; HTTP |
| `sdk.modules.setup.applyDatabase` | `POST /api/setup/database` | application/json; HTTP |
| `sdk.modules.setup.finish` | `POST /api/setup/finish` | application/json; HTTP |
| `sdk.modules.setup.initialAdmin` | `POST /api/setup/initial-admin` | application/json; HTTP |
| `sdk.modules.setup.setupPresets` | `GET /api/setup/presets` | parameters; HTTP |
| `sdk.modules.setup.resumeWizard` | `POST /api/setup/resume-wizard` | parameters; HTTP |
| `sdk.modules.setup.status` | `GET /api/setup/status` | parameters; HTTP |
| `sdk.modules.setup.testDatabase` | `POST /api/setup/test-database` | application/json; HTTP |
| `sdk.modules.setup.testProviderDraft` | `POST /api/setup/test-provider` | application/json; HTTP |
| `sdk.modules.setup.validateWizardToken` | `GET /api/setup/validate-token` | parameters; HTTP |
| `sdk.modules.setup.verifyPassword` | `POST /api/setup/verify-password` | application/json; HTTP |

## skillPackages

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.skillPackages.listSkillPackages` | `GET /api/skill-packages` | parameters; HTTP |
| `sdk.modules.skillPackages.createSkillPackage` | `POST /api/skill-packages` | application/json; HTTP |
| `sdk.modules.skillPackages.createFromSkillhub` | `POST /api/skill-packages/from-skillhub` | application/json; HTTP |
| `sdk.modules.skillPackages.packageHubRankings` | `GET /api/skill-packages/hub/rankings` | parameters; HTTP |
| `sdk.modules.skillPackages.packageHubSearch` | `GET /api/skill-packages/hub/search` | parameters; HTTP |
| `sdk.modules.skillPackages.deleteSkillPackage` | `DELETE /api/skill-packages/{package_id}` | parameters; HTTP |
| `sdk.modules.skillPackages.getSkillPackage` | `GET /api/skill-packages/{package_id}` | parameters; HTTP |
| `sdk.modules.skillPackages.updateSkillPackage` | `PATCH /api/skill-packages/{package_id}` | application/json; HTTP |
| `sdk.modules.skillPackages.listPackageSkills` | `GET /api/skill-packages/{package_id}/skills` | parameters; HTTP |
| `sdk.modules.skillPackages.createPackageSkill` | `POST /api/skill-packages/{package_id}/skills` | application/json; HTTP |
| `sdk.modules.skillPackages.hubInstallPackageSkill` | `POST /api/skill-packages/{package_id}/skills/hub/install` | application/json; HTTP |
| `sdk.modules.skillPackages.importPackageSkill` | `POST /api/skill-packages/{package_id}/skills/import` | application/json; HTTP |
| `sdk.modules.skillPackages.deletePackageSkill` | `DELETE /api/skill-packages/{package_id}/skills/{slug}` | parameters; HTTP |
| `sdk.modules.skillPackages.getPackageSkill` | `GET /api/skill-packages/{package_id}/skills/{slug}` | parameters; HTTP |
| `sdk.modules.skillPackages.updatePackageSkill` | `PUT /api/skill-packages/{package_id}/skills/{slug}` | application/json; HTTP |

## skills

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.skills.listSkillPackageMounts` | `GET /api/agents/{agent_id}/skill-packages` | parameters; HTTP |
| `sdk.modules.skills.replaceSkillPackageMounts` | `PUT /api/agents/{agent_id}/skill-packages` | application/json; HTTP |
| `sdk.modules.skills.copySkillPackageToWorkspace` | `POST /api/agents/{agent_id}/skill-packages/{package_id}/copy` | application/json; HTTP |
| `sdk.modules.skills.listSkills` | `GET /api/agents/{agent_id}/skills` | parameters; HTTP |
| `sdk.modules.skills.createSkill` | `POST /api/agents/{agent_id}/skills` | application/json; HTTP |
| `sdk.modules.skills.copySkillFromAgent` | `POST /api/agents/{agent_id}/skills/copy` | application/json; HTTP |
| `sdk.modules.skills.hubInstallSkill` | `POST /api/agents/{agent_id}/skills/hub/install` | application/json; HTTP |
| `sdk.modules.skills.hubRankings` | `GET /api/agents/{agent_id}/skills/hub/rankings` | parameters; HTTP |
| `sdk.modules.skills.hubSearchSkills` | `GET /api/agents/{agent_id}/skills/hub/search` | parameters; HTTP |
| `sdk.modules.skills.importSkillFromUrl` | `POST /api/agents/{agent_id}/skills/import` | application/json; HTTP |
| `sdk.modules.skills.deleteSkill` | `DELETE /api/agents/{agent_id}/skills/{name}` | parameters; HTTP |
| `sdk.modules.skills.getSkill` | `GET /api/agents/{agent_id}/skills/{name}` | parameters; HTTP |
| `sdk.modules.skills.updateSkill` | `PUT /api/agents/{agent_id}/skills/{name}` | application/json; HTTP |
| `sdk.modules.skills.disableSkill` | `POST /api/agents/{agent_id}/skills/{name}/disable` | parameters; HTTP |
| `sdk.modules.skills.enableSkill` | `POST /api/agents/{agent_id}/skills/{name}/enable` | parameters; HTTP |
| `sdk.modules.skills.pushWorkspaceSkillToPackage` | `POST /api/agents/{agent_id}/skills/{name}/push-to-package` | application/json; HTTP |
| `sdk.modules.skills.hubRankingsGlobal` | `GET /api/skills/hub/rankings` | parameters; HTTP |
| `sdk.modules.skills.hubSearchSkillsGlobal` | `GET /api/skills/hub/search` | parameters; HTTP |

## slash

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.slash.listSlashCommands` | `GET /api/slash/commands` | parameters; HTTP |

## storageBackends

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.storageBackends.listStorageBackendsForUser` | `GET /api/storage-backends` | parameters; HTTP |

## subagents

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.subagents.listSubagents` | `GET /api/agents/{agent_id}/subagents` | parameters; HTTP |
| `sdk.modules.subagents.installSubagent` | `POST /api/agents/{agent_id}/subagents/install` | application/json; HTTP |
| `sdk.modules.subagents.listSubagentCatalog` | `GET /api/subagent-catalog` | parameters; HTTP |
| `sdk.modules.subagents.listSubagentDivisions` | `GET /api/subagent-catalog/divisions` | parameters; HTTP |
| `sdk.modules.subagents.getSubagentCatalogItem` | `GET /api/subagent-catalog/{slug}` | parameters; HTTP |

## teams

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.teams.listTeams` | `GET /api/teams` | parameters; HTTP |
| `sdk.modules.teams.createTeam` | `POST /api/teams` | application/json; HTTP |
| `sdk.modules.teams.teamTemplateFiles` | `GET /api/teams/template` | parameters; HTTP |
| `sdk.modules.teams.deleteTeam` | `DELETE /api/teams/{team_id}` | parameters; HTTP |
| `sdk.modules.teams.getTeam` | `GET /api/teams/{team_id}` | parameters; HTTP |
| `sdk.modules.teams.patchTeam` | `PATCH /api/teams/{team_id}` | application/json; HTTP |

## terminal

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.terminal.terminalContext` | `GET /api/agents/{agent_id}/terminal/context` | parameters; HTTP |

## tls

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.tls.tlsIssue` | `POST /api/admin/tls/issue` | application/json; HTTP |
| `sdk.modules.tls.tlsPreflight` | `POST /api/admin/tls/preflight` | application/json; HTTP |
| `sdk.modules.tls.tlsStatus` | `GET /api/admin/tls/status` | parameters; HTTP |

## update

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.update.checkForUpdates` | `POST /api/update/check` | parameters; HTTP |
| `sdk.modules.update.upgradeProgress` | `GET /api/update/progress` | parameters; HTTP |
| `sdk.modules.update.restartServiceEndpoint` | `POST /api/update/restart` | parameters; HTTP |
| `sdk.modules.update.updateSettings` | `PATCH /api/update/settings` | application/json; HTTP |
| `sdk.modules.update.updateStatus` | `GET /api/update/status` | parameters; HTTP |
| `sdk.modules.update.triggerUpgrade` | `POST /api/update/upgrade` | application/json; HTTP |

## usage

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.usage.userExport` | `GET /api/usage/export.xlsx` | parameters; stream-or-binary |
| `sdk.modules.usage.userSummary` | `GET /api/usage/summary` | parameters; HTTP |

## users

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.users.listUsers` | `GET /api/users` | parameters; HTTP |
| `sdk.modules.users.createUser` | `POST /api/users` | application/json; HTTP |
| `sdk.modules.users.batchUsers` | `POST /api/users/batch` | application/json; HTTP |
| `sdk.modules.users.listInvites` | `GET /api/users/invites` | parameters; HTTP |
| `sdk.modules.users.createInvite` | `POST /api/users/invites` | application/json; HTTP |
| `sdk.modules.users.revokeInvite` | `POST /api/users/invites/{invite_id}/revoke` | parameters; HTTP |
| `sdk.modules.users.listPermissionCatalog` | `GET /api/users/permissions` | parameters; HTTP |
| `sdk.modules.users.listUserRoles` | `GET /api/users/roles` | parameters; HTTP |
| `sdk.modules.users.createUserRole` | `POST /api/users/roles` | application/json; HTTP |
| `sdk.modules.users.deleteUserRole` | `DELETE /api/users/roles/{user_role_id}` | parameters; HTTP |
| `sdk.modules.users.patchUserRole` | `PATCH /api/users/roles/{user_role_id}` | application/json; HTTP |
| `sdk.modules.users.deleteRoleAvatar` | `DELETE /api/users/roles/{user_role_id}/avatar` | parameters; HTTP |
| `sdk.modules.users.getRoleAvatar` | `GET /api/users/roles/{user_role_id}/avatar` | parameters; HTTP |
| `sdk.modules.users.uploadRoleAvatar` | `POST /api/users/roles/{user_role_id}/avatar` | multipart/form-data; HTTP |
| `sdk.modules.users.deleteUser` | `DELETE /api/users/{user_id}` | parameters; HTTP |
| `sdk.modules.users.getUser` | `GET /api/users/{user_id}` | parameters; HTTP |
| `sdk.modules.users.patchUser` | `PATCH /api/users/{user_id}` | application/json; HTTP |
| `sdk.modules.users.deleteUserAvatar` | `DELETE /api/users/{user_id}/avatar` | parameters; HTTP |
| `sdk.modules.users.getUserAvatar` | `GET /api/users/{user_id}/avatar` | parameters; HTTP |
| `sdk.modules.users.uploadUserAvatar` | `POST /api/users/{user_id}/avatar` | multipart/form-data; HTTP |
| `sdk.modules.users.resetPassword` | `POST /api/users/{user_id}/reset-password` | application/json; HTTP |
| `sdk.modules.users.unlockUserLogin` | `POST /api/users/{user_id}/unlock-login` | parameters; HTTP |

## voice

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.voice.getActiveVoice` | `GET /api/voice/active` | parameters; HTTP |
| `sdk.modules.voice.setActiveVoice` | `PUT /api/voice/active` | application/json; HTTP |
| `sdk.modules.voice.listVoicePresets` | `GET /api/voice/presets` | parameters; HTTP |
| `sdk.modules.voice.listVoiceProviders` | `GET /api/voice/providers` | parameters; HTTP |
| `sdk.modules.voice.transcribeAudio` | `POST /api/voice/stt` | multipart/form-data; HTTP |
| `sdk.modules.voice.synthesizeSpeech` | `POST /api/voice/tts` | application/json; stream-or-binary |

## workspace

| SDK 方法 | 原生方法 / 路径 | 请求与流 |
| --- | --- | --- |
| `sdk.modules.workspace.previewMedia` | `GET /api/agents/{agent_id}/media/preview` | parameters; stream-or-binary |
| `sdk.modules.workspace.exportWorkspaceArchive` | `GET /api/agents/{agent_id}/workspace/archive` | parameters; stream-or-binary |
| `sdk.modules.workspace.importWorkspaceArchive` | `POST /api/agents/{agent_id}/workspace/archive` | multipart/form-data; stream-or-binary |
| `sdk.modules.workspace.readDoc` | `GET /api/agents/{agent_id}/workspace/doc` | parameters; HTTP |
| `sdk.modules.workspace.writeDoc` | `PUT /api/agents/{agent_id}/workspace/doc` | application/json; HTTP |
| `sdk.modules.workspace.downloadFile` | `GET /api/agents/{agent_id}/workspace/download` | parameters; stream-or-binary |
| `sdk.modules.workspace.deleteWorkspaceFile` | `DELETE /api/agents/{agent_id}/workspace/file` | parameters; HTTP |
| `sdk.modules.workspace.readFile` | `GET /api/agents/{agent_id}/workspace/file` | parameters; HTTP |
| `sdk.modules.workspace.writeFile` | `PUT /api/agents/{agent_id}/workspace/file` | application/json; HTTP |
| `sdk.modules.workspace.globFiles` | `GET /api/agents/{agent_id}/workspace/glob` | parameters; HTTP |
| `sdk.modules.workspace.grepFiles` | `GET /api/agents/{agent_id}/workspace/grep` | parameters; HTTP |
| `sdk.modules.workspace.mkdirWorkspaceDir` | `POST /api/agents/{agent_id}/workspace/mkdir` | parameters; HTTP |
| `sdk.modules.workspace.moveWorkspaceFile` | `POST /api/agents/{agent_id}/workspace/move` | application/json; HTTP |
| `sdk.modules.workspace.listTree` | `GET /api/agents/{agent_id}/workspace/tree` | parameters; HTTP |
| `sdk.modules.workspace.uploadFile` | `POST /api/agents/{agent_id}/workspace/upload` | multipart/form-data; HTTP |

## 追加管理协议 V1

上述457项为冻结的平台快照；新增15项产品管理与应用profile能力通过 `sdk.applications` 与 `sdk.modules.applications` 调用，类型与HTTP路径见[产品管理协议](applications.md)。总计472项HTTP操作、43个模块。
