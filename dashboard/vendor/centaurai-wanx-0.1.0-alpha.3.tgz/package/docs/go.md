# centaurai-wanx：Go 宿主接入

源码交付中的 `native` 模块提供账号、设备目录、签票、P2P、原生 SSO、HTTP 响应流和原生 WebSocket。它没有重新实现记忆；记忆与其他模块继续请求 WANX 原生 API。

Go 源码没有发布远端 tag。将源码解压到应用旁边，在应用的 `go.mod` 中使用本地引用。依赖模块的 replace 不会传递给上层应用，因此三条 replace 都要设置：

```go
module example.com/wanx-application

go 1.24.0

require centaurai-wanx/native v0.1.0-alpha.1

replace centaurai-wanx/native => ../centaurai-wanx/native
replace codeup.aliyun.com/667637d76d5f7b05cc5d9ed7/nexusaos/nexusaos-centuarai-conn-sdks.git/go => ../centaurai-wanx/native/upstream-sdk
replace codeup.aliyun.com/667637d76d5f7b05cc5d9ed7/nexusaos/nexusaos-centuarai-os.git/p2p-core-go => ../centaurai-wanx/native/upstream-core
```

其他公开 Go 依赖通过 `go.sum` 固定；首次源码构建需要公开模块源或已准备的模块缓存。运行 npm 交付内的 native host 不需要 Go 或私有仓库访问。

宿主创建 `wanx.New(wanx.Config{Consumer: ..., Connectivity: ..., Policy: ...})`。`Consumer` 使用原始 `consumer.Config`：受信 Consumer 地址、宿主安全存储及 `consumer.NativeSigner`。签名私钥留在宿主；不要给页面或日志提供 signer、完整 `AuthSession`、票据或原生 JWT。`Connectivity` 的网关/ICE 域名信任配置沿用最新 Go SDK。

流程为 `host.Consumer.LoginPassword` 或 `Login` → `Devices` → 用户选定设备 → `host.Connect(ctx, deviceID, "", "")` → 原生 HTTP/WS。现有账号关联使用显式的 username/password 双证明；首次 owner 初始化调用返回 session 的 `InitializeOwner`。

```go
response, err := host.Request(ctx, "POST",
    "/api/agents/authorized-agent/memory/atoms/list",
    http.Header{"Content-Type": {"application/json"}},
    strings.NewReader(`{"limit":20}`))
if err != nil { return err }
defer response.Body.Close()
// response.StatusCode 与 Body 保持原生结果；下载直接流式读取 Body。
```

调用路径、参数、原生 JSON 和 multipart 结构参照[完整 API 目录](api-reference.md)及 `api-baseline/openapi.json`。只有已列入 `Policy.Operations` 的方法/路径能通过；Agent 路径和旧 `X-Octop-Agent-Id` 受 `Policy.Agents` 限制。策略限制本机调用范围，实际资源授权和用户角色继续由服务端决定。

`host.OpenSocket(ctx, endpoint, relativePath)` 限定七类原生 WS，保留文本/二进制消息。原生 JWT 在宿主内部注入，拒绝 caller token 和 start 消息覆盖身份。连接关闭、鉴权失效和续租失败都会关闭消息流；应用退出调用 `host.Close()`。

当前 `Policy.ApplicationID` 的批准连接合同为 `omnia-desktop`。新应用登记和其他网络模式需要平台端合同支持，见[服务端配套要求](backend-contract.md)。
