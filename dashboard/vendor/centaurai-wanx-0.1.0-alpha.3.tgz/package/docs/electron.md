# centaurai-wanx：Electron 接入

主进程使用 root SDK，preload 仅转发固定 IPC，renderer 使用 `centaurai-wanx/renderer`。一个绑定对应一个受批准的主窗口；销毁窗口时释放绑定及 native host。若应用有多个角色窗口，应为各窗口提供独立受审策略，不共享一个全权限门面。

## main

```ts
import { app, BrowserWindow, ipcMain, safeStorage } from "electron";
import { createCentaurAIWanxHost, createElectronSecureStore } from "centaurai-wanx";
import { bindCentaurAIWanxElectron } from "centaurai-wanx/electron-main";

await app.whenReady();
const host = await createCentaurAIWanxHost({
  ...trustedDeployment,
  policy: approvedApplicationPolicy,
  secureStore: createElectronSecureStore({ safeStorage, directory: app.getPath("userData") }),
});
const window = new BrowserWindow({ webPreferences: {
  preload: compiledPreloadPath, contextIsolation: true, sandbox: true, nodeIntegration: false,
} });
const dispose = bindCentaurAIWanxElectron({
  ipcMain, host, webContentsId: window.webContents.id, documentURL: applicationDocumentURL,
});
window.once("closed", () => { void dispose(); });
await window.loadURL(applicationDocumentURL);
```

main 核验窗口 ID、主 frame、完整 document URL（允许同文档 hash 变化）。跳转、iframe 与其他窗口被拒绝。拒绝 native JWT 签发类 API 的 renderer 调用；账号与密码/SMS 流程使用专门 auth 门面。Owner 初始化及显式旧用户关联由可信 main 处理。

原生密码登录、邀请注册兑换、OAuth/OIDC exchange、旧版初始管理员创建及 wizard token 签发仅可由可信 main 调用，不能通过通用 IPC 把它们的凭据响应转发到页面。其余原生操作仍需要主进程策略与服务端权限批准。

## sandbox preload（CommonJS）

```js
const { contextBridge, ipcRenderer } = require("electron");
const { exposeCentaurAIWanxPreload } = require("centaurai-wanx/electron-preload");
exposeCentaurAIWanxPreload({ contextBridge, ipcRenderer });
```

sandbox preload 的 `require` 受 Electron 限制，应把本段和 SDK preload 入口打包为单个 CommonJS preload 文件，保留 `electron` 为 external。SDK 同时提供 CJS preload 产物，内部不导入 Node API。不要把整个 root SDK 打进 preload。

## renderer

```ts
import { createCentaurAIWanxApp } from "centaurai-wanx/renderer";
const app = createCentaurAIWanxApp({ bridge: window.centauraiWanx, policy: publicPolicyView });
await app.auth.loginPassword({ phone, password });
const devices = await app.devices.list();
const sdk = await app.connection.connect({ deviceId: selectedDeviceId });
const result = await sdk.agents.use(authorizedAgentId).memory.listAtoms({ body: { limit: 20 } });
```

renderer 策略仅用于显示与类型；即使页面伪造它，main 仍按自己的策略和真实服务端身份检查。SDK session 没有 `native` 字段。流逐块拉取、WS逐消息拉取，不把票据、私钥或原生 token 作为页面参数。

## 打包与存储

把安装包的 `native/bin` 解包到可执行目录，例如 Electron Builder 的 `asarUnpack: ["node_modules/centaurai-wanx/native/bin/**"]`。默认加载器处理 `.asar.unpacked`，并在启动前核验随包 SHA256；不要改用 PATH 上同名程序。

`safeStorage` 加密后才写入 `userData/centaurai-wanx.credentials.enc`，临时文件以 0600 原子替换。平台不提供有效加密或 Linux 使用 `basic_text` 后端时，SDK返回 `SECURE_STORAGE_UNAVAILABLE`。应用无需自行存放明文 token 或 ECDSA 私钥。

各应用应使用独立的 userData 目录。SDK 的网络 applicationId、部署地址和获准资源只能由主进程提供。关闭 session 关闭流与 WS；登出同时清除 Consumer 会话；保存的客户端身份继续用于同一应用下次登录。

## 新产品与管理员客户端

新增产品管理、应用授权、版本与profile调用继续经过SDK main白名单；客户端不得把登录JWT或任意native.invoke暴露给renderer。产品创建时网络identity仍为pending，远程P2P仍需正式登记。生成Electron工程可使用[产品管理协议与生成器](applications.md)，通过可信HTTPS/回环HTTP联调。
