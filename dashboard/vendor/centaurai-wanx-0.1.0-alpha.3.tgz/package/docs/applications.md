# WANX 产品管理协议 V1

SDK 固定平台基线仍为 457 项 HTTP 操作、42 个模块；本轮增加独立协议 V1 的 15 项操作，实际客户端共 472 项操作、43 个模块。追加目录与 Go companion 共用白名单，原基线和来源证明保持不变。

产品能力目前由服务端识别 chat / memory / knowledge / upload / voice；清单不能把SDK接口目录当作已授权能力。资源需求使用 kind（model / provider / storage / skill / plugin）和 required，部署绑定值为资源标识字符串。profile 响应含 application_id 与 agent_id（未创建时可能为 null）。

管理方法均返回 `NativeResponse<T>`，保留服务端状态码与响应体。客户端本地 policy 是调用范围，不授予管理员角色。Electron renderer 的调用仍经过 main 端不可变 policy，不允许传入 token、原生凭据或 `as_user`。

```ts
const products = await client.applications.list();
const definition = await client.applications.get("demo.product");
await client.applications.putDeployment("demo.product", {
  enabled: true, resource_bindings: {}, configuration: {},
});
await client.applications.putAccess("demo.product", { user_id: 12, enabled: true });
const update = await client.applications.compatibleRelease("demo.product", {
  platform: "macos", arch: "arm64", current_version: "0.1.0", sdk_version: "0.1.0-alpha.2",
});
```

| 方法 | HTTP 接口 |
| --- | --- |
| list / create | GET / POST `/api/admin/applications` |
| get / update | GET / PATCH `/api/admin/applications/{application_id}` |
| getDeployment / putDeployment | GET / PUT `…/{application_id}/deployment` |
| listReleases / createRelease | GET / POST `…/{application_id}/releases` |
| recommendRelease | POST `…/{application_id}/releases/{version}/recommend`，请求含 platform / arch |
| listAccess / putAccess | GET / PUT `…/{application_id}/access`，PUT 含 user_id / enabled |
| getManifest | GET `…/{application_id}/manifest` |
| compatibleRelease | GET `/api/applications/{application_id}/release`，查询 platform / arch / current_version / sdk_version |
| getProfile / createProfile | GET / POST `/api/applications/{application_id}/profile` |

`ApplicationProduct` 的 `connection_identity` 明确返回 `status: "pending"` 与 `remote_enabled: false`。创建产品不代表登记了平台网络身份。现有原生 P2P 合同仅支持 `omnia-desktop`；其他产品连接会返回 `APPLICATION_CONTRACT_NOT_SUPPORTED`，不得借用该身份。真实签票、盒子会话与统一身份登记仍需平台合同支持。

产品管理接口保存产品定义、盒子部署、安装包版本和用户开通状态。个人 Agent / 记忆 / 会话继续由 WANX 管理，管理门面没有私人内容读取入口；profile 返回本人的应用域 Agent ID，随后调用已有 `client.agents.use(id).memory`。

## SDK 工程生成

```ts
import { generateWanxApplicationProject } from "centaurai-wanx/project-generator";

await generateWanxApplicationProject({
  directory: "/path/to/new-product", // 必须是空目录
  manifest: (await client.applications.getManifest("demo.product")).body,
  sdkTarball: "/path/to/centaurai-wanx-0.1.0-alpha.2.tgz", // 本地 npm pack 包
});
```

生成可编译的 React / TypeScript / Electron 工程、产品清单、公司私有 LICENSE 和接入说明。SDK tgz 复制到 vendor，避免假设此私有包已发布到公开 registry。导出仅保留协议清单字段，检测到 token / password / secret / api_key 等凭据键时拒绝生成；不会导出账号记录、用户实例或个人记忆。

生成的 Electron main 使用 SDK 的可信 HTTPS / 回环 HTTP 适配器，登录 JWT 与加密凭据不进入 renderer。preload 仅允许固定方法；main 再校验窗口、顶层 frame 与固定文档来源。界面包含盒子地址登记、登录、本人 profile、原生记忆调用和兼容版本检查。切换盒子需先断开，所有请求串行执行，权限拒绝会清理连接。生成工程的 P2P 入口保持不可用。

此流程为开发工程交付。实际服务端权限、真实盒子 P2P、桌面、macOS / Windows 安装与系统签名需分别验收，不由一次本机模拟测试证明。
