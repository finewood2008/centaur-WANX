# 第三方与来源说明

公司自有代码和文档遵循[专有许可](LICENSE)。公司声明不覆盖或撤销第三方既有授权。

- WANX 原生 API 类型与 schema 来自记录的平台快照；原始平台声明原样保存在[平台 NOTICE](third-party/native-platform-NOTICE)。
- 连接源码来自 Codeup `f0e9c63452e531b1f51024911637feae73738320` 的 Go SDK 0.2.0，以及该交付中冻结的 Core 0.1.1。原始文件的 SHA256 记录在源码交付的 `provenance-files.json`。本项目没有替这些组件额外授予 MIT 许可。
- 原始 Go 文件保持一致；新增适配代码和测试位于 `upstream-sdk/omniaauth/centaurai_wanx*.go`。Core 原始文件未修改。当前公共合同未修改；Core 独立测试夹具仅投影一项分层错误码，说明见源码 `native/core-test-contracts/README.md`。
- native host 的 22 项 Go 运行依赖、固定版本及原始许可文件索引见[Go 依赖清单](third-party/go-dependencies.json)。
- Node 运行依赖 `ws` 8.22.0 的原始版权和 MIT 许可见[ws LICENSE](third-party/ws-LICENSE)。
- 原生程序使用 Go 工具链构建；其随附声明见[Go LICENSE](third-party/Go-LICENSE)。

开发工具 TypeScript 与 Node 类型包由 npm 分别提供原始许可；它们不是本 npm 安装包的运行依赖。SDK 自有代码仍按公司专有产品交付。
